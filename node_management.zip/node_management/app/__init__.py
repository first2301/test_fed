"""FL Container Dashboard 애플리케이션"""
from .main import app

__all__ = ['app']

